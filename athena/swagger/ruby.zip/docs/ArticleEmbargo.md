# SwaggerClient::ArticleEmbargo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_embargoed** | **BOOLEAN** | True if embargoed | [optional] 
**embargo_reason** | **String** | Reason for embargo | [optional] 


