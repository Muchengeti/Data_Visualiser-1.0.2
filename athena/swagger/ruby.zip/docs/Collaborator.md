# SwaggerClient::Collaborator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role_name** | **String** | Collaborator role | [optional] 
**user_id** | **Integer** | Collaborator id | [optional] 
**name** | **String** | Collaborator name | [optional] 


