# SwaggerClient::Role

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Role id | [optional] 
**name** | **String** | Role name | [optional] 
**category** | **String** | Role category | [optional] 
**description** | **String** | Role description | [optional] 


