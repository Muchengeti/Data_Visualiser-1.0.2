# SwaggerClient::ProjectCollaborator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | Status of collaborator invitation | [optional] 
**role_name** | **String** | Collaborator role | [optional] 
**user_id** | **Integer** | Collaborator id | [optional] 
**name** | **String** | Collaborator name | [optional] 


