# SwaggerClient::Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parent_id** | **Integer** | Parent category | [optional] 
**id** | **Integer** | Category id | [optional] 
**title** | **String** | Category title | [optional] 


