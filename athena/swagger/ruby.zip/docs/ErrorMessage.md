# SwaggerClient::ErrorMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** | A machine friendly error code, used by the dev team to identify the error. | [optional] 
**message** | **String** | A human friendly message explaining the error. | [optional] 


